package edu.upf;

import com.github.tukaaa.MastodonDStream;
import com.github.tukaaa.config.AppConfig;
import com.github.tukaaa.model.SimplifiedTweetWithHashtags;
import org.apache.spark.SparkConf;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.StreamingContext;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

public static void main(String[] args) throws InterruptedException {
    SparkConf conf = new SparkConf().setAppName("Real-time Mastodon With State");
    AppConfig appConfig = AppConfig.getConfig();

    StreamingContext sc = new StreamingContext(conf, Durations.seconds(10));
    JavaStreamingContext jsc = new JavaStreamingContext(sc);
    jsc.checkpoint("/tmp/checkpoint");

    JavaDStream<SimplifiedTweetWithHashtags> stream = new MastodonDStream(sc, appConfig).asJStream();

    // TODO IMPLEMENT ME
    String language = args[0].toLowerCase();

    stream
        .filter(tweet -> tweet.getLanguage().toLowerCase().equals(language))
        .mapToPair(tweet -> new Tuple2<>(tweet.getUserId(), 1))
        .updateStateByKey((toots, state) -> { int sum = state.or(0);
        for (int toot : toots) {
            sum += toot;
        }
        return Optional.of(sum);
    }, StateSpec.function((Function2<List<Integer>, Optional<Integer>, Optional<Integer>>) (toots, state) -> {
        int sum = state.or(0);
        for (int toot : toots) {
            sum += toot;
        }
        return Optional.of(sum);
    }))
    .mapToPair(pair -> pair.swap())
    .transformToPair(pair -> pair.sortByKey(false)).print(20);
    
    // Start the application and wait for termination signal
    jsc.start();
    jsc.awaitTermination();
}
