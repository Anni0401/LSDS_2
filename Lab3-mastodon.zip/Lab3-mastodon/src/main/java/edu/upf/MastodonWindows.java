package edu.upf;

import com.github.tukaaa.MastodonDStream;
import com.github.tukaaa.config.AppConfig;
import com.github.tukaaa.model.SimplifiedTweetWithHashtags;

import edu.upf.util.LanguageMapUtils;
import scala.Tuple2;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.StreamingContext;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaDStreamLike;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.dstream.DStream;
import org.apache.spark.streaming.dstream.WindowedDStream;

public class MastodonWindows {
    public static void main(String[] args) {
        String input = args[0];

        SparkConf conf = new SparkConf().setAppName("Real-time Mastodon Stateful with Windows Exercise");
        AppConfig appConfig = AppConfig.getConfig();

        StreamingContext sc = new StreamingContext(conf, Durations.seconds(20));
        JavaStreamingContext jsc = new JavaStreamingContext(sc);
        sc.checkpoint("/tmp/checkpoint");

        // TODO IMPLEMENT ME
        JavaDStream<SimplifiedTweetWithHashtags> stream = new MastodonDStream(sc, appConfig).asJStream();

        final JavaDStream<SimplifiedTweetWithHashtags> windowedStream = stream.window(Durations.seconds(20));

        JavaRDD<String> lines = jsc.sparkContext().textFile(input);
        JavaPairRDD<String, String> staticrdd = LanguageMapUtils.buildLanguageMap(lines);

        stream.mapToPair(tweet -> new Tuple2<String, Integer> (tweet.getLanguage(), 1)).reduceByKey((x,y) -> x+y)
        .transformToPair(rdd->rdd.join(staticrdd).mapToPair(tuple -> new Tuple2 <> (tuple._2._1, tuple._2._2))
        .sortByKey(false)).mapToPair(x -> x.swap()).print(15);

        windowedStream.mapToPair(tweet -> new Tuple2<String, Integer> (tweet.getLanguage(), 1)).reduceByKeyAndWindow((x,y) -> x+y, Durations.seconds(60))
        .transformToPair(rdd->rdd.join(staticrdd).mapToPair(tuple -> new Tuple2 <> (tuple._2._1, tuple._2._2))
        .sortByKey(false)).mapToPair(x -> x.swap()).print(15);
        
        // Start the application and wait for termination signal
        sc.start();
        sc.awaitTermination();
    }

}
